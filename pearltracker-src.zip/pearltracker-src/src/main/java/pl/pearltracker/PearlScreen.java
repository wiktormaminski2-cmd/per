package pl.pearltracker;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import java.util.List;

public class PearlScreen extends Screen {

    private static final int MAX_ROWS = 12;

    public PearlScreen() {
        super(Text.literal("Pearl Tracker"));
    }

    @Override
    protected void init() {
        addDrawableChild(ButtonWidget.builder(Text.literal("Wyczysc"), b -> PearlTrackerMod.ENTRIES.clear())
                .dimensions(width / 2 - 105, height - 30, 100, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Zamknij"), b -> close())
                .dimensions(width / 2 + 5, height - 30, 100, 20).build());
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        super.render(ctx, mouseX, mouseY, delta);

        int x = width / 2 - 170;
        int y = 30;
        ctx.drawCenteredTextWithShadow(textRenderer, "\u00a7lPearl Tracker \u00a77(L zamyka)", width / 2, 12, 0xFFFFFF);

        List<PearlTrackerMod.Entry> list = PearlTrackerMod.ENTRIES;
        if (list.isEmpty()) {
            ctx.drawCenteredTextWithShadow(textRenderer, "Brak rzuconych perel", width / 2, y + 20, 0xAAAAAA);
            return;
        }

        ctx.drawTextWithShadow(textRenderer, "Gracz", x, y, 0xFFAA00);
        ctx.drawTextWithShadow(textRenderer, "Rzucil z", x + 90, y, 0xFFAA00);
        ctx.drawTextWithShadow(textRenderer, "Wyladowala", x + 200, y, 0xFFAA00);
        ctx.drawTextWithShadow(textRenderer, "Kiedy", x + 310, y, 0xFFAA00);
        y += 14;

        int shown = 0;
        for (int i = list.size() - 1; i >= 0 && shown < MAX_ROWS; i--, shown++) {
            PearlTrackerMod.Entry e = list.get(i);
            long sec = (System.currentTimeMillis() - e.time) / 1000;
            ctx.drawTextWithShadow(textRenderer, e.player, x, y, 0xFFFFFF);
            ctx.drawTextWithShadow(textRenderer, PearlTrackerMod.fmt(e.from), x + 90, y, 0xBBBBBB);
            ctx.drawTextWithShadow(textRenderer, PearlTrackerMod.fmt(e.to), x + 200, y, 0x55FF55);
            ctx.drawTextWithShadow(textRenderer, sec + "s temu", x + 310, y, 0x888888);
            y += 12;
        }
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (keyCode == GLFW.GLFW_KEY_L) {
            close();
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override
    public boolean shouldPause() {
        return false;
    }
}
