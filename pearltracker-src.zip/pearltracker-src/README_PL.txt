PEARL TRACKER - kod zrodlowy (NIE wrzucaj tego do folderu mods!)

Co robi: pokazuje kto rzucil perle Endermana, skad i gdzie wyladowala.
Klawisz: L (otwiera i zamyka okno). Do zmiany w Opcje > Sterowanie > Klawisze.
Wymaga: Minecraft 1.21.4 + Fabric Loader + Fabric API.

JAK DOSTAC PRAWDZIWY MOD (.jar) PRZEZ GITHUB:
1. github.com/new  -> nazwa np. pearltracker, Public, Create repository.
2. Kliknij "uploading an existing file".
3. Przeciagnij ZAWARTOSC tego folderu: src, .github, build.gradle,
   settings.gradle, gradle.properties (oraz README_PL.txt).
4. Na dole kliknij zielony "Commit changes".
5. Zakladka Actions -> poczekaj na zielony znaczek -> kliknij ukonczony
   build -> na dole "Artifacts" -> pobierz pearltracker-jar.
6. Rozpakuj pobrany plik. W srodku jest pearltracker-1.0.0.jar - TO jest mod.
7. Wrzuc go do .minecraft/mods razem z plikiem fabric-api (wersja 1.21.4).

SPRAWDZENIE: otworz .jar w 7-Zip. Maja byc: fabric.mod.json, folder pl
(z plikami .class) oraz folder assets. Jesli widzisz src i build.gradle,
to jest kod, a nie mod.
